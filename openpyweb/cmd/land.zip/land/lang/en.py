{"lng.test": "Sample text"}
